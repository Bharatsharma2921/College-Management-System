
import CollegeApp from "./CollegeApp";

function App() {
  return (
    <div className="App">
      <CollegeApp></CollegeApp>
      
      
    </div>
  );
}

export default App;
