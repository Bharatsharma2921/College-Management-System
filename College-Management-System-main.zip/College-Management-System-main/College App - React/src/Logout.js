import React,{Component} from 'react';

class Logout extends Component{

    render(){

        return(
            <div className="container">
                <h1>Thanks for using our app</h1>
            </div>
        );
    }
}

export default Logout;