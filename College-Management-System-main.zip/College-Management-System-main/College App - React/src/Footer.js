import React,{Component} from 'react';

class Footer extends Component{

    render(){

        return(
            <footer className="footer">
                <span className="text-muted"><b> All Rights Reserved 2021 <a href="https://github.com/vishnukotesh/College-Management-System---Full-Stack-Application" 
                title="Go to my GitHub profile of this project" target="_blank">@VishnuKotesh</a></b></span>


            </footer>
        );
    }
}

export default Footer;